import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import laravel from 'laravel-vite-plugin'
import path from 'path'

export default defineConfig({
  plugins: [
    laravel({
      input: [
        'resources/css/app.css',
        'resources/js/app.jsx',
        'resources/js/pages/login.jsx',
        'resources/js/pages/home.jsx',
        'resources/js/pages/empresas.jsx',
        'resources/js/pages/hub-empresa.jsx',
        'resources/js/pages/posto-trabalho.jsx',
        'resources/js/pages/rula.jsx',
        'resources/js/pages/checklists.jsx',
        'resources/js/pages/arp-questionario.jsx',
        'resources/js/pages/dashboard.jsx',
        'resources/js/pages/usuarios.jsx',
        'resources/js/pages/identidade-visual.jsx',
      ],
      refresh: true,
    }),
    react(),
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'resources/js'),
    },
  },
})

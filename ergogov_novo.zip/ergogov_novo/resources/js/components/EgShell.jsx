// Shared components for ergo.gov — compiled for Vite/React
import React from 'react';

export const EG_NAV_ITEMS = [
  { id: 'home',       label: 'Início',           icon: 'home',      href: '/home' },
  { id: 'empresas',   label: 'Empresas',         icon: 'building',  href: '/empresas' },
  { id: 'usuarios',   label: 'Usuários',         icon: 'users',     href: '/usuarios' },
  { id: 'identidade', label: 'Identidade visual',icon: 'palette',   href: '/identidade' },
  { id: 'logout',     label: 'Sair',             icon: 'logout',    href: '/logout' },
];

export const EgIcon = {
  home:        (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"><path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v9a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1v-9"/></svg>,
  building:    (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M9 7h.01M9 11h.01M9 15h.01M15 7h.01M15 11h.01M15 15h.01"/><path d="M10 21v-4h4v4"/></svg>,
  users:       (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"><path d="M16 19a4 4 0 0 0-8 0"/><circle cx="12" cy="10" r="4"/><path d="M22 19a4 4 0 0 0-3-3.87"/><path d="M2 19a4 4 0 0 1 3-3.87"/><circle cx="18" cy="8" r="2.5"/><circle cx="6" cy="8" r="2.5"/></svg>,
  palette:     (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"><circle cx="13.5" cy="6.5" r="1.5" fill="currentColor"/><circle cx="17.5" cy="10.5" r="1.5" fill="currentColor"/><circle cx="8.5" cy="7.5" r="1.5" fill="currentColor"/><circle cx="6.5" cy="12.5" r="1.5" fill="currentColor"/><path d="M12 22a9 9 0 1 1 0-18c4.97 0 9 3.58 9 8 0 2.21-1.79 4-4 4h-1.5a2 2 0 0 0-1 3.75A1.3 1.3 0 0 1 13.5 22Z"/></svg>,
  logout:      (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/></svg>,
  search:      (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>,
  bell:        (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10 21a2 2 0 0 0 4 0"/></svg>,
  help:        (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.5 9a2.5 2.5 0 1 1 4 2c-.5.4-1.5 1-1.5 2v.5"/><circle cx="12" cy="17" r=".5" fill="currentColor"/></svg>,
  chevronDown: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>,
  plus:        (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"><path d="M12 5v14M5 12h14"/></svg>,
  arrowRight:  (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></svg>,
  pdf:         (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/><path d="M9 14h6M9 18h4"/></svg>,
  trendUp:     (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"><path d="m3 17 6-6 4 4 8-8"/><path d="M14 7h7v7"/></svg>,
};

export function EgWordmark({ size = 22, theme = 'light' }) {
  const color = theme === 'light' ? 'var(--white)' : 'var(--ink-900)';
  return (
    <span style={{ fontSize: size, fontWeight: 800, letterSpacing: '-0.03em', color, fontFamily: 'var(--font-sans)' }}>
      ergo<span style={{ color: 'var(--g-400)' }}>.</span><span style={{ color: theme === 'light' ? 'var(--g-300)' : 'var(--g-600)' }}>gov</span>
    </span>
  );
}

export function EgSidebar({ active = 'home' }) {
  return (
    <aside style={{
      width: 220, background: 'var(--sidebar)', display: 'flex', flexDirection: 'column',
      minHeight: '100vh', position: 'sticky', top: 0, flexShrink: 0,
    }}>
      <div style={{ padding: '24px 20px 16px', borderBottom: '1px solid var(--sidebar-line)' }}>
        <EgWordmark size={20} theme="light" />
      </div>
      <div style={{ padding: '12px 12px 4px', fontSize: 11, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--sidebar-fg-muted)' }}>
        Menu
      </div>
      <nav style={{ flex: 1, padding: '4px 8px' }}>
        {EG_NAV_ITEMS.map((item) => {
          const Icon = EgIcon[item.icon];
          const isActive = active === item.id;
          return (
            <a key={item.id} href={item.href} style={{
              display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px',
              borderRadius: 8, marginBottom: 2, fontSize: 14, fontWeight: isActive ? 600 : 400,
              color: isActive ? 'var(--white)' : 'var(--sidebar-fg-muted)',
              background: isActive ? 'rgba(255,255,255,0.12)' : 'transparent',
              borderLeft: isActive ? '3px solid var(--g-400)' : '3px solid transparent',
              transition: 'all 0.15s',
            }}>
              {Icon && <Icon style={{ width: 17, height: 17, strokeWidth: 1.75, flexShrink: 0 }} />}
              {item.label}
            </a>
          );
        })}
      </nav>
      <div style={{ padding: '12px 20px', borderTop: '1px solid var(--sidebar-line)', fontSize: 11, color: 'var(--sidebar-fg-muted)' }}>
        ergo.gov v1.0
      </div>
    </aside>
  );
}

export function EgTopbar({ breadcrumbs = [], user = { name: 'Usuário', initials: 'U' } }) {
  return (
    <header style={{
      height: 60, background: 'var(--white)', borderBottom: '1px solid var(--line-1)',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 32px', position: 'sticky', top: 0, zIndex: 10,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, fontWeight: 500, color: 'var(--ink-500)' }}>
        {breadcrumbs.map((b, i) => (
          <React.Fragment key={i}>
            {i > 0 && <span style={{ color: 'var(--ink-300)' }}>/</span>}
            <span style={i === breadcrumbs.length - 1 ? { color: 'var(--ink-900)', fontWeight: 600 } : {}}>{b}</span>
          </React.Fragment>
        ))}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <button style={{ width: 38, height: 38, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', borderRadius: 8, background: 'transparent', border: '1px solid transparent', color: 'var(--ink-500)', transition: 'all 0.15s' }}>
          <EgIcon.bell style={{ width: 18, height: 18, strokeWidth: 1.75 }} />
        </button>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 12px 4px 4px', borderRadius: 20, border: '1px solid var(--line-2)', background: 'var(--white)' }}>
          <div style={{ width: 30, height: 30, borderRadius: '50%', background: 'linear-gradient(135deg, var(--g-700), var(--g-500))', color: 'var(--white)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 600 }}>
            {user.initials}
          </div>
          <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--ink-800)' }}>{user.name}</span>
        </div>
      </div>
    </header>
  );
}

export function EgShell({ active, breadcrumbs, user, children }) {
  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--canvas)' }}>
      <EgSidebar active={active} />
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <EgTopbar breadcrumbs={breadcrumbs} user={user} />
        <main style={{ flex: 1, padding: 32 }}>
          {children}
        </main>
      </div>
    </div>
  );
}

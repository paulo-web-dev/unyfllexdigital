<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\IdentidadeVisual;
use App\Models\Empresas;
use Auth;

class IdentidadeVisualController extends Controller
{
    use ReactViewController;

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function show($id_empresa)
    {
        $identidade = IdentidadeVisual::where('id_empresa', $id_empresa)->first();
        $empresa = Empresas::findOrFail($id_empresa);

        return $this->reactView('identidade-visual', [
            'identidade' => $identidade?->toArray() ?? [],
            'empresa'    => ['id' => $empresa->id, 'nome' => $empresa->nome],
            'user'       => ['name' => Auth::user()->name, 'initials' => strtoupper(substr(Auth::user()->name, 0, 1))],
        ]);
    }

    public function save(Request $request)
    {
        $identidade = IdentidadeVisual::updateOrCreate(
            ['id_empresa' => $request->id_empresa],
            [
                'cor_principal'   => $request->cor_principal,
                'logo'            => $request->logo,
                'nome_empresa'    => $request->nome_empresa,
                'cabecalho_texto' => $request->cabecalho_texto,
                'rodape_texto'    => $request->rodape_texto,
            ]
        );
        return back()->with('success', 'Identidade visual salva.');
    }
}

<?php

namespace App\Http\Controllers;

trait ReactViewController
{
    /**
     * Return a React-powered view.
     * The blade template sets page_script and passes props as JSON to data-props.
     */
    protected function reactView(string $page, array $props = [])
    {
        return view('pages.' . $page, [
            'page_script' => $page,
            'props' => $props,
        ]);
    }
}

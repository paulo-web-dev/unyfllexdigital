<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Empresas;
use Auth;

class HomeController extends Controller
{
    use ReactViewController;

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function home()
    {
        $user = Auth::user();
        $empresas = Empresas::where('id_user', $user->id_instituicao ?? $user->id)
            ->with(['area', 'planodeacao', 'mapeamento'])
            ->get();

        return $this->reactView('home', [
            'user' => ['name' => $user->name, 'initials' => strtoupper(substr($user->name, 0, 1))],
            'totalEmpresas' => $empresas->count(),
        ]);
    }

    public function logout()
    {
        Auth::logout();
        return redirect('/login');
    }
}

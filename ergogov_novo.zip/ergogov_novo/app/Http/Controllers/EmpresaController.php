<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Empresas;
use App\Models\Setores;
use App\Models\SubSetores;
use App\Models\Area;
use Auth;

class EmpresaController extends Controller
{
    use ReactViewController;

    public function __construct()
    {
        $this->middleware('auth')->except(['formArpPublico']);
    }

    // Lista de empresas
    public function show()
    {
        $empresas = Empresas::where('id_user', Auth::user()->id_instituicao ?? Auth::user()->id)
            ->with(['area', 'mapeamento', 'planodeacao'])
            ->get()
            ->map(function ($e) {
                $total = $e->area->count();
                return [
                    'id'        => $e->id,
                    'nome'      => $e->nome,
                    'cnpj'      => $e->cnpj,
                    'titulo'    => $e->titulo,
                    'progresso' => $total > 0 ? min(100, intval(($e->mapeamento->count() / max($total * 3, 1)) * 100)) : 0,
                    'status'    => $e->mapeamento->count() > 0 ? 'Em andamento' : 'Novo',
                ];
            });

        return $this->reactView('empresas', [
            'empresas' => $empresas,
            'user' => ['name' => Auth::user()->name, 'initials' => strtoupper(substr(Auth::user()->name, 0, 1))],
        ]);
    }

    // Hub da empresa
    public function infoempresa($id)
    {
        $empresa = Empresas::with([
            'area.setores.subsetores',
            'cabecalho', 'rodape', 'identidade',
            'planodeacao', 'mapeamento',
        ])->findOrFail($id);

        return $this->reactView('hub-empresa', [
            'empresa' => $empresa->toArray(),
            'user' => ['name' => Auth::user()->name, 'initials' => strtoupper(substr(Auth::user()->name, 0, 1))],
        ]);
    }

    // Dashboard gerencial
    public function dashboard($id)
    {
        $empresa = Empresas::with([
            'area.setores.subsetores.mapeamento',
            'mapeamento', 'planodeacao',
        ])->findOrFail($id);

        return $this->reactView('dashboard', [
            'empresa' => $empresa->toArray(),
            'user' => ['name' => Auth::user()->name, 'initials' => strtoupper(substr(Auth::user()->name, 0, 1))],
        ]);
    }

    // Salvar/atualizar empresa
    public function cadempresa(Request $request)
    {
        $empresa = new Empresas();
        $empresa->nome     = $request->nome;
        $empresa->cnpj     = $request->cnpj;
        $empresa->titulo   = $request->titulo;
        $empresa->id_user  = Auth::user()->id_instituicao ?? Auth::user()->id;
        $empresa->save();

        return redirect()->route('infoempresa', ['id' => $empresa->id]);
    }

    public function updempresa(Request $request)
    {
        $empresa = Empresas::findOrFail($request->id);
        $empresa->nome   = $request->nome;
        $empresa->cnpj   = $request->cnpj;
        $empresa->titulo = $request->titulo;
        $empresa->save();

        return redirect()->route('infoempresa', ['id' => $empresa->id]);
    }
}

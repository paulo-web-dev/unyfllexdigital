<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SubSetores;
use App\Models\Setores;
use Auth;

class SubSetoresController extends Controller
{
    use ReactViewController;

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function infosubsetor($id)
    {
        $subsetor = SubSetores::with([
            'funcao', 'tarefa', 'analiseatividade', 'foto', 'descricaofoto',
            'caracteristicas', 'dadossaude', 'prediagnostico',
            'rula', 'owas', 'niosh', 'kim', 'mooregarg', 'suerodgers',
            'recomendacao',
        ])->findOrFail($id);

        return $this->reactView('posto-trabalho', [
            'subsetor' => $subsetor->toArray(),
            'user' => ['name' => Auth::user()->name, 'initials' => strtoupper(substr(Auth::user()->name, 0, 1))],
        ]);
    }

    public function cadsubsetor(Request $request)
    {
        $sub = new SubSetores();
        $sub->nome        = $request->nome;
        $sub->descricao   = $request->descricao;
        $sub->id_setor    = $request->id_setor;
        $sub->save();
        return redirect()->route('info-setor', ['id' => $request->id_setor]);
    }

    public function updsubsetor(Request $request)
    {
        $sub = SubSetores::findOrFail($request->id);
        $sub->nome      = $request->nome;
        $sub->descricao = $request->descricao;
        $sub->save();
        return back()->with('success', 'Posto atualizado.');
    }
}

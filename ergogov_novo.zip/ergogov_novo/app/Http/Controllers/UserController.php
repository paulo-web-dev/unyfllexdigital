<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Auth;

class UserController extends Controller
{
    use ReactViewController;

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function show()
    {
        $users = User::where('id_instituicao', Auth::user()->id_instituicao ?? Auth::user()->id)
            ->get()
            ->map(fn($u) => [
                'id'         => $u->id,
                'name'       => $u->name,
                'email'      => $u->email,
                'perfil'     => $u->perfil ?? 'Técnico',
                'ativo'      => $u->ativo ?? true,
                'ultimo_acesso' => $u->updated_at?->diffForHumans() ?? '—',
                'initials'   => strtoupper(substr($u->name, 0, 1)),
            ]);

        return $this->reactView('usuarios', [
            'users' => $users,
            'user'  => ['name' => Auth::user()->name, 'initials' => strtoupper(substr(Auth::user()->name, 0, 1))],
        ]);
    }
}

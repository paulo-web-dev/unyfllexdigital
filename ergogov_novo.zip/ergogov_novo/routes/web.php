<?php

use App\Http\Controllers\LoginController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\EmpresaController;
use App\Http\Controllers\SetoresController;
use App\Http\Controllers\SubSetoresController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\IdentidadeVisualController;
use App\Http\Controllers\RulaController;
use App\Http\Controllers\OwasController;
use App\Http\Controllers\NioshController;
use App\Http\Controllers\KimController;
use App\Http\Controllers\MooreGargController;
use App\Http\Controllers\SueRodgersController;
use App\Http\Controllers\ChecklistsController;
use App\Http\Controllers\ArpController;
use App\Http\Controllers\RelatorioController;
use App\Http\Controllers\PlanoDeAcaoController;
use App\Http\Controllers\RecomendacaoController;
use App\Http\Controllers\CabecalhoController;
use App\Http\Controllers\RodapeController;
use App\Http\Controllers\AreaController;
use App\Http\Controllers\FuncaoController;
use App\Http\Controllers\TarefaController;
use App\Http\Controllers\AnaliseAtividadeController;
use App\Http\Controllers\FotoController;
use App\Http\Controllers\DescricaoFotoController;
use App\Http\Controllers\CaracteristicasController;
use App\Http\Controllers\DadosSaudeController;
use App\Http\Controllers\PreDiagnosticoController;
use App\Http\Controllers\CargosController;
use App\Http\Controllers\PopulacaoController;
use App\Http\Controllers\PopulacaoSubSetorController;
use App\Http\Controllers\MetodologiaController;
use App\Http\Controllers\ObjetivosController;
use App\Http\Controllers\IntroducaoController;
use App\Http\Controllers\ConclusaoController;
use App\Http\Controllers\ConclusaoSubsetorController;
use App\Http\Controllers\MapeamentoController;
use App\Http\Controllers\EquipeController;
use App\Http\Controllers\ResponsaveisController;
use App\Http\Controllers\AnaliseGlobalController;
use App\Http\Controllers\TextosController;
use Illuminate\Support\Facades\Route;

// ─── Auth ────────────────────────────────────────────────────────────────────
Route::get('/',       [LoginController::class, 'showLogin'])->name('login');
Route::get('/login',  [LoginController::class, 'showLogin'])->name('login.show');
Route::post('/login', [LoginController::class, 'login'])->name('login.post');
Route::get('/logout', [LoginController::class, 'logout'])->name('logout');

// ─── Public ARP form ─────────────────────────────────────────────────────────
Route::get('/formulario/arp/{id}',       [ArpController::class, 'formArp'])->name('form-arp');
Route::post('/formulario/cad/respostas/arp', [ArpController::class, 'cadForm'])->name('cad-form-arp');
Route::get('/formulario/enviado/arp',    [ArpController::class, 'formArpEnviado'])->name('form-arp-enviado');

// ─── Authenticated routes ────────────────────────────────────────────────────
Route::middleware('auth')->group(function () {

    // Dashboard home
    Route::get('/home', [HomeController::class, 'home'])->name('home');

    // Empresas
    Route::get('/empresas',            [EmpresaController::class, 'show'])->name('show-empresas');
    Route::post('/empresas/cadastrar', [EmpresaController::class, 'cadempresa'])->name('cadempresa');
    Route::post('/empresas/atualizar', [EmpresaController::class, 'updempresa'])->name('updempresa');
    Route::get('/empresa/{id}',        [EmpresaController::class, 'infoempresa'])->name('infoempresa');
    Route::get('/empresa/{id}/dashboard', [EmpresaController::class, 'dashboard'])->name('dashboardempresa');

    // ARP internal (admin)
    Route::get('/empresa/{id}/arp/link', [ArpController::class, 'geraLink'])->name('gera-link-arp');
    Route::get('/empresa/{id}/arp/dashboard', [ArpController::class, 'dashboardArp'])->name('dashboard-arp');

    // Relatório
    Route::get('/empresa/{id}/relatorio', [RelatorioController::class, 'gerar'])->name('gera-relatorio');

    // Áreas
    Route::post('/area/cadastrar',  [AreaController::class, 'cadarea'])->name('cad-area');
    Route::get('/area/{id}',        [AreaController::class, 'infoarea'])->name('info-area');
    Route::post('/area/atualizar',  [AreaController::class, 'updarea'])->name('upd-area');

    // Setores
    Route::post('/setor/cadastrar', [SetoresController::class, 'cadsetor'])->name('cad-setor');
    Route::get('/setor/{id}',       [SetoresController::class, 'infosetor'])->name('info-setor');
    Route::post('/setor/atualizar', [SetoresController::class, 'updsetor'])->name('upd-setor');

    // Subsetores / Postos de Trabalho
    Route::post('/subsetor/cadastrar', [SubSetoresController::class, 'cadsubsetor'])->name('cad-subsetor');
    Route::get('/subsetor/{id}',       [SubSetoresController::class, 'infosubsetor'])->name('info-subsetor');
    Route::post('/subsetor/atualizar', [SubSetoresController::class, 'updsubsetor'])->name('upd-subsetor');

    // Ferramentas biomecânicas
    Route::post('/rula/cadastrar',     [RulaController::class, 'cadrula'])->name('cad-rula');
    Route::post('/owas/cadastrar',     [OwasController::class, 'cadowas'])->name('cad-owas');
    Route::post('/niosh/cadastrar',    [NioshController::class, 'cadniosh'])->name('cad-niosh');
    Route::post('/kim/cadastrar',      [KimController::class, 'cadkim'])->name('cad-kim');
    Route::post('/moore/cadastrar',    [MooreGargController::class, 'cadmoore'])->name('cad-moore');
    Route::post('/suerodgers/cadastrar', [SueRodgersController::class, 'cadsuerodgers'])->name('cad-suerodgers');

    // Checklists
    Route::post('/checklists/cadastrar', [ChecklistsController::class, 'cadchecklists'])->name('cad-checklists');
    Route::get('/checklists/{id}',       [ChecklistsController::class, 'infochecklists'])->name('info-checklists');

    // Recomendações e Plano de Ação
    Route::post('/recomendacao/cadastrar',  [RecomendacaoController::class, 'cadrecomendacao'])->name('cad-recomendacao');
    Route::post('/plano-acao/upload',       [PlanoDeAcaoController::class, 'upload'])->name('upload-plano-de-acao');

    // Cabeçalho / Rodapé
    Route::get('/cabecalho/{id}',          [CabecalhoController::class, 'infocabecalho'])->name('info-cabecalho');
    Route::post('/cabecalho/cadastrar',    [CabecalhoController::class, 'cadcabecalho'])->name('cad-cabecalho');
    Route::get('/cabecalho/form/{id}',     [CabecalhoController::class, 'formcabecalho'])->name('form-cabecalho');
    Route::get('/rodape/{id}',             [RodapeController::class, 'inforodape'])->name('info-rodape');
    Route::post('/rodape/cadastrar',       [RodapeController::class, 'cadrodape'])->name('cad-rodape');
    Route::get('/rodape/form/{id}',        [RodapeController::class, 'formrodape'])->name('form-rodape');

    // Demais módulos da AET
    Route::post('/funcao/cadastrar',      [FuncaoController::class, 'cadfuncao'])->name('cad-funcao');
    Route::post('/tarefa/cadastrar',      [TarefaController::class, 'cadtarefa'])->name('cad-tarefa');
    Route::post('/analise-atividade/cadastrar', [AnaliseAtividadeController::class, 'cadanalise'])->name('cad-analise-atividade');
    Route::post('/foto/cadastrar',        [FotoController::class, 'cadfoto'])->name('cad-foto');
    Route::post('/descricao-foto/cadastrar', [DescricaoFotoController::class, 'caddescricao'])->name('cad-descricao-foto');
    Route::post('/caracteristicas/cadastrar', [CaracteristicasController::class, 'cadcaracteristicas'])->name('cad-caracteristicas');
    Route::post('/dados-saude/cadastrar', [DadosSaudeController::class, 'caddadossaude'])->name('cad-dados-saude');
    Route::post('/pre-diagnostico/cadastrar', [PreDiagnosticoController::class, 'cadprediagnostico'])->name('cad-pre-diagnostico');
    Route::post('/populacao/cadastrar',   [PopulacaoController::class, 'cadpopulacao'])->name('cad-populacao');
    Route::post('/populacao-subsetor/cadastrar', [PopulacaoSubSetorController::class, 'cadpopulacao'])->name('cad-populacao-subsetor');
    Route::post('/metodologia/cadastrar', [MetodologiaController::class, 'cadmetodologia'])->name('cad-metodologia');
    Route::post('/objetivos/cadastrar',   [ObjetivosController::class, 'cadobjetivos'])->name('cad-objetivos');
    Route::post('/introducao/cadastrar',  [IntroducaoController::class, 'cadintroducao'])->name('cad-introducao');
    Route::post('/conclusao/cadastrar',   [ConclusaoController::class, 'cadconclusao'])->name('cad-conclusao');
    Route::post('/conclusao-subsetor/cadastrar', [ConclusaoSubsetorController::class, 'cadconclusao'])->name('cad-conclusao-subsetor');
    Route::post('/mapeamento/cadastrar',  [MapeamentoController::class, 'cadmapeamento'])->name('cad-mapeamento');
    Route::post('/equipe/cadastrar',      [EquipeController::class, 'cadequipe'])->name('cad-equipe');
    Route::post('/responsaveis/cadastrar', [ResponsaveisController::class, 'cadresponsaveis'])->name('cad-responsaveis');
    Route::post('/analise-global/cadastrar', [AnaliseGlobalController::class, 'cadanalise'])->name('cad-analise-global');
    Route::post('/textos/cadastrar',      [TextosController::class, 'cadtextos'])->name('cad-textos');

    // Usuários
    Route::get('/usuarios',             [UserController::class, 'show'])->name('show-usuarios');

    // Identidade Visual
    Route::get('/empresa/{id}/identidade',  [IdentidadeVisualController::class, 'show'])->name('show-identidade');
    Route::post('/identidade/salvar',       [IdentidadeVisualController::class, 'save'])->name('salvar-identidade');

    // Cargos
    Route::post('/cargo/cadastrar',     [CargosController::class, 'cadcargo'])->name('cad-cargo');
    Route::get('/cargo/{id}',           [CargosController::class, 'infocargo'])->name('info-cargo');
});
